/*
The below trigger will check if the person exists if so a raiserror will show that the user 
does not exist
*/
CREATE TRIGGER trCheckIfExists ON tblPerson
FOR INSERT 
AS 

DECLARE @ID int
IF EXISTS 
     (Select * from TblPerson
	 where PersonID in (SELECT PersonID FROM TblPerson)
	 GROUP BY PersonID,InsertedDate,FirstName,LastName,Email,CellNo
	 having COUNT(*) > 1
	 AND PersonID = @ID)
BEGIN 
RAISERROR('The record already exists',10,1)
ROLLBACK
END 



             
