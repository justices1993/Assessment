/*
   The below script creates a table and also the relationship of each table and they 
   are all linked together to allow for joins and I also added constraints as well to
   ensure that there is data integrity and consistency on the data.
*/

CREATE TABLE tblPerson
(
  PersonID int PRIMARY KEY IDENTITY(1,1),
  InsertedDate datetime not null,
  FirstName varchar(50) not null,
  LastName varchar(50) not null,
  Email varchar(50),
  CellNo varchar(50)
)

USE AdminDB

GO 

CREATE TABLE tblAddress
(
  AddressID int PRIMARY KEY IDENTITY(1,1),
  PersonID int,
  AddressDescription varchar(100),
  InsertedDate datetime,
  FOREIGN KEY(PersonID) REFERENCES tblPerson(PersonID)
)

GO 

CREATE TABLE tblGender 
(
  GenderID int PRIMARY KEY,
  PersonID int,
  Description varchar(50),
  InsertedDate datetime,
  FOREIGN KEY(PersonID) REFERENCES tblPerson(PersonID),
  CONSTRAINT CH_CheckGender CHECK (Description in ('Male', 'Female','Unknown')),
  CONSTRAINT CH_CheckID CHECK (GenderID in (1,2,3))
)

GO 

CREATE TABLE tblMarried
(
  MarriedID bit PRIMARY KEY,
  PersonID int not null,
  GenderID int not null,
  Description varchar(10),
  FOREIGN KEY(PersonID) REFERENCES tblPerson(PersonID),
  FOREIGN KEY(GenderID) REFERENCES tblGender(GenderID),
  CONSTRAINT DF_CheckDescription CHECK(Description in ('Married','Single','Widow'))
)

