/*
  The below stored procedure will delete an existing item on the database based on the actual id
  This is also a secure way to work with outside data coming from different source

*/
CREATE PROCEDURE DeletePerson (@ID int) 
AS 
BEGIN 
  IF @ID IS NOT NULL
  DELETE FROM TblPerson
  WHERE PersonID = @ID

END
