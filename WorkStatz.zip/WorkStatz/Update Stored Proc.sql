/*
The below stored procedure will update the existing data from the tblPerson table where 
the PersonID will match the parameterid

*/
CREATE PROCEDURE UpdatePerson (@PersonID int,@FirstName varchar(50), @LastName varchar(50),@Email varchar(50), @CellNo varchar(15)) 
AS 
BEGIN 
    UPDATE 
	  TblPerson
	SET 
	FirstName =  @FirstName,
	LastName = @LastName,
	Email = @Email,
	CellNo = @CellNo

	WHERE 
	PersonID  = @PersonID
END 