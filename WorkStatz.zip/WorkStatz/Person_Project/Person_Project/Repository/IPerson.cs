﻿using System;
using Person_Project.Model;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace Person_Project.Repository
{
    public interface IPerson
    {
        Task<int> AddPerson(PersonModel person);
    }
}
