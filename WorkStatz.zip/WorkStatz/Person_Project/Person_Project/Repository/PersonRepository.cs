﻿using System;
using Person_Project.Model;
using System.Collections.Generic;
using System.Threading.Tasks;


//namespace Person_Project.Repository
/*{
    public class PersonRepository : IPerson 
    {
       
    }
}*/
