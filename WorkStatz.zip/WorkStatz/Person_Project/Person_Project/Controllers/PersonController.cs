﻿using Microsoft.AspNetCore.Mvc;
using System;
using Person_Project.Model;
using System.Data.SqlClient;
using System.Data;
using Microsoft.AspNetCore.Http;


namespace Person_Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonController : ControllerBase
    {
        string constr = "Data Source=SM-JUSTICES-NB;Initial Catalog=DotNetPeTips;User ID=Tester;Password=Password123/";
        [HttpPost]
        public async Task<ActionResult<PersonModel>> addPerson(PersonModel personmodel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            using (SqlConnection con = new SqlConnection(constr))
            {
              //Add a new Person using the data access layer or a stored procedure
                    SqlCommand cmd = new SqlCommand("AddPerson", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@FirstName", personmodel.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", personmodel.LastName);
                    cmd.Parameters.AddWithValue("@Email", personmodel.Email);
                    cmd.Parameters.AddWithValue("@CellNo", personmodel.CellNo);

                    con.Open();
                    int i = cmd.ExecuteNonQuery();
                    if (i > 0)
                    {
                        return Ok();
                    }
                    con.Close();
            }
            return BadRequest();

        }

        // PUT: api/Person/5
        [HttpPut("{id}")]
        public async Task<IActionResult> updatePerson(int id, PersonModel personmodel)
        {
            if (id != personmodel.Id)
            {
                return BadRequest();
            }
            PersonModel person = new PersonModel();
            if (ModelState.IsValid)
            {
                using (SqlConnection con = new SqlConnection(constr))
                {
                    //Update Person from the update stored procedure
                    SqlCommand cmd = new SqlCommand("UpdatePerson", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@FirstName", personmodel.FirstName);
                        cmd.Parameters.AddWithValue("@LastName", personmodel.LastName);
                        cmd.Parameters.AddWithValue("@Email", personmodel.Email);
                        cmd.Parameters.AddWithValue("@CellNo", personmodel.CellNo);
                        cmd.Parameters.AddWithValue("@ID", id);

                    con.Open();
                        int i = cmd.ExecuteNonQuery();
                        if (i > 0)
                        {
                            return NoContent();
                        }
                        con.Close();
                    }              

            }
            return BadRequest(ModelState);
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePerson(int id)
        {

            using (SqlConnection con = new SqlConnection(constr))
            {
                //Delete person from the delete stored procedure
                SqlCommand cmd = new SqlCommand("DeletePerson", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", id);

                con.Open();
                    int i = cmd.ExecuteNonQuery();
                    if (i > 0)
                    {
                        return NoContent();
                    }
                    con.Close();
              
            }
            return BadRequest();
        }


    }
}
