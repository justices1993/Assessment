
--Unique Clustered Index
CREATE UNIQUE NONCLUSTERED INDEX UCI_PersonID on tblPerson
(InsertedDate,FirstName,LastName,Email,CellNo)

--NonClustered Index
CREATE NONCLUSTERED INDEX UCI_AddressID on tblAddress
(AddressDescription)

