/*
  The below stored procedure allows acts as a data access layer that will write the data to the database which provide a more
  securable way of outside applications speaking directly to the database and also prevent SQL injections as well the below query 
  allows me to pass in the parameters instead of the actual tablename and column
*/


CREATE PROCEDURE AddPerson (@FirstName varchar(50), @LastName varchar(50),@Email varchar(50),@CellNo varchar(15))
AS 
BEGIN

SET NOCOUNT ON

INSERT INTO tblPerson (FirstName,LastName,Email,CellNo) 
VALUES 
(
 @FirstName,
 @LastName,
 @Email,
 @CellNo
)
   PRINT 'A new person has been added ' + @FirstName + ' the email account added is ' + @Email
END

