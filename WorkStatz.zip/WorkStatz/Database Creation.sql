/*
  A database is created as AdminDB,the use command allows the database to be selected when executed 
  This allows a user to use the new database
*/

CREATE DATABASE AdminDB

GO 

USE AdminDB




